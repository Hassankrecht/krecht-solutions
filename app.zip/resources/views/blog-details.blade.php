@extends('layouts.app')
@section('content')
 

    <!-- Page Title -->
    <div class="page-title" data-aos="fade">
      <div class="container">
        <nav class="breadcrumbs">
          <ol>
            <li><a href="index.html">Home</a></li>
            <li class="current">Blog Details</li>
          </ol>
        </nav>
        <h1>Blog Details</h1>
      </div>
    </div><!-- End Page Title -->

    <div class="container">
      <div class="row">

        <div class="col-lg-8">

          <!-- Blog Details Section -->
          <section id="blog-details" class="blog-details section">
            <div class="container" data-aos="fade-up">

              <article class="article">

                <div class="hero-img" data-aos="zoom-in">
                  <img src="assets/img/blog/blog-post-3.webp" alt="Featured blog image" class="img-fluid" loading="lazy">
                  <div class="meta-overlay">
                    <div class="meta-categories">
                      <a href="#" class="category">Web Development</a>
                      <span class="divider">•</span>
                      <span class="reading-time"><i class="bi bi-clock"></i> 6 min read</span>
                    </div>
                  </div>
                </div>

                <div class="article-content" data-aos="fade-up" data-aos-delay="100">
                  <div class="content-header">
                    <h1 class="title">Modern Web Development: Best Practices and Future Trends for 2025</h1>

                    <div class="author-info">
                      <div class="author-details">
                        <img src="assets/img/person/person-f-8.webp" alt="Author" class="author-img">
                        <div class="info">
                          <h4>Michael Chen</h4>
                          <span class="role">Senior Web Developer</span>
                        </div>
                      </div>
                      <div class="post-meta">
                        <span class="date"><i class="bi bi-calendar3"></i> Mar 15, 2025</span>
                        <span class="divider">•</span>
                        <span class="comments"><i class="bi bi-chat-text"></i> 18 Comments</span>
                      </div>
                    </div>
                  </div>

                  <div class="content">
                    <p class="lead">
                      The landscape of web development continues to evolve at an unprecedented pace, bringing new technologies, frameworks, and methodologies that reshape how we build modern web applications.
                    </p>

                    <p>
                      As we delve into 2025, the web development ecosystem has transformed dramatically, introducing innovative approaches to building faster, more secure, and highly engaging web experiences. This comprehensive guide explores the latest trends and best practices that are defining the future of web development.
                    </p>

                    <div class="content-image right-aligned">
                      <img src="assets/img/blog/blog-hero-2.webp" class="img-fluid" alt="Modern web development tools" loading="lazy">
                      <figcaption>Modern development environments emphasize collaboration and efficiency</figcaption>
                    </div>

                    <h2>The Rise of Web Components</h2>
                    <p>
                      Web Components have become increasingly crucial in modern web development, offering a standardized way to create reusable custom elements. Key advantages include:
                    </p>
                    <ul>
                      <li>Enhanced code reusability across different frameworks</li>
                      <li>Better encapsulation of functionality</li>
                      <li>Improved maintenance and scalability</li>
                      <li>Framework-agnostic component development</li>
                    </ul>

                    <div class="highlight-box">
                      <h3>Key Trends in 2025</h3>
                      <ul class="trend-list">
                        <li>
                          <i class="bi bi-lightning-charge"></i>
                          <span>Edge Computing and Serverless Architecture</span>
                        </li>
                        <li>
                          <i class="bi bi-shield-check"></i>
                          <span>Enhanced Security Measures</span>
                        </li>
                        <li>
                          <i class="bi bi-phone"></i>
                          <span>Progressive Web Apps (PWAs)</span>
                        </li>
                      </ul>
                    </div>

                    <h2>Performance Optimization</h2>
                    <p>
                      Performance remains a critical factor in web development, with an increasing focus on Core Web Vitals and user experience metrics. Modern applications must be optimized for both speed and efficiency.
                    </p>

                    <blockquote>
                      <p>
                        "The future of web development lies not just in writing code, but in creating seamless, accessible, and performant experiences that work for everyone, everywhere."
                      </p>
                      <cite>Emily Thompson, Web Performance Architect</cite>
                    </blockquote>

                    <div class="content-grid">
                      <div class="row g-4">
                        <div class="col-md-6">
                          <div class="info-card">
                            <i class="bi bi-speedometer2"></i>
                            <h4>Performance Metrics</h4>
                            <p>Focus on Core Web Vitals and user-centric performance metrics for better search rankings and user experience.</p>
                          </div>
                        </div>
                        <div class="col-md-6">
                          <div class="info-card">
                            <i class="bi bi-universal-access"></i>
                            <h4>Accessibility</h4>
                            <p>Implementing WCAG guidelines and ensuring web applications are accessible to all users across different devices.</p>
                          </div>
                        </div>
                      </div>
                    </div>

                    <h2>Looking Forward</h2>
                    <p>
                      As we continue through 2025, web development practices will further evolve, embracing new technologies while maintaining a strong foundation in performance, accessibility, and user experience. Staying updated with these trends and best practices is crucial for developers looking to build modern, scalable web applications.
                    </p>
                  </div>

                  <div class="meta-bottom">
                    <div class="tags-section">
                      <h4>Related Topics</h4>
                      <div class="tags">
                        <a href="#" class="tag">Web Development</a>
                        <a href="#" class="tag">Performance</a>
                        <a href="#" class="tag">Best Practices</a>
                        <a href="#" class="tag">Trends</a>
                        <a href="#" class="tag">2025</a>
                      </div>
                    </div>

                    <div class="share-section">
                      <h4>Share Article</h4>
                      <div class="social-links">
                        <a href="#" class="twitter"><i class="bi bi-twitter-x"></i></a>
                        <a href="#" class="facebook"><i class="bi bi-facebook"></i></a>
                        <a href="#" class="linkedin"><i class="bi bi-linkedin"></i></a>
                        <a href="#" class="copy-link" title="Copy Link"><i class="bi bi-link-45deg"></i></a>
                      </div>
                    </div>
                  </div>
                </div>

              </article>

            </div>
          </section><!-- /Blog Details Section -->

          <!-- Blog Comments Section -->
          <section id="blog-comments" class="blog-comments section">

            <div class="container" data-aos="fade-up" data-aos-delay="100">

              <div class="blog-comments-4">
                <div class="comments-header">
                  <h3 class="title">Community Feedback</h3>
                  <div class="comments-stats">
                    <span class="count">12</span>
                    <span class="label">Comments</span>
                  </div>
                </div>

                <div class="comments-container">
                  <!-- Comment #1 -->
                  <div class="comment-thread">
                    <div class="comment-box">
                      <div class="comment-wrapper">
                        <div class="avatar-wrapper">
                          <img src="assets/img/person/person-f-9.webp" alt="Avatar" loading="lazy">
                          <span class="status-indicator"></span>
                        </div>

                        <div class="comment-content">
                          <div class="comment-header">
                            <div class="user-info">
                              <h4>Thomas Anderson</h4>
                              <span class="time-badge">
                                <i class="bi bi-clock"></i>
                                2 hours ago
                              </span>
                            </div>
                            <div class="engagement">
                              <span class="likes">
                                <i class="bi bi-heart"></i>
                                24
                              </span>
                            </div>
                          </div>

                          <div class="comment-body">
                            <p>Nullam ac urna eu felis dapibus condimentum sit amet a augue. Sed non neque elit. Sed ut imperdiet nisi. Proin condimentum fermentum nunc.</p>
                          </div>

                          <div class="comment-actions">
                            <button class="action-btn like-btn" aria-label="Like comment">
                              <i class="bi bi-heart"></i>
                              <span>Like</span>
                            </button>
                            <button class="action-btn reply-btn" aria-label="Reply to comment">
                              <i class="bi bi-chat"></i>
                              <span>Reply</span>
                            </button>
                            <button class="action-btn share-btn" aria-label="Share comment">
                              <i class="bi bi-share"></i>
                              <span>Share</span>
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>

                    <!-- Replies Container -->
                    <div class="replies-container">
                      <!-- Reply #1 -->
                      <div class="comment-box reply">
                        <div class="comment-wrapper">
                          <div class="avatar-wrapper">
                            <img src="assets/img/person/person-m-9.webp" alt="Avatar" loading="lazy">
                            <span class="status-indicator"></span>
                          </div>

                          <div class="comment-content">
                            <div class="comment-header">
                              <div class="user-info">
                                <h4>Maria Rodriguez</h4>
                                <span class="time-badge">
                                  <i class="bi bi-clock"></i>
                                  1 hour ago
                                </span>
                              </div>
                              <div class="engagement">
                                <span class="likes">
                                  <i class="bi bi-heart"></i>
                                  8
                                </span>
                              </div>
                            </div>

                            <div class="comment-body">
                              <p>Vivamus elementum semper nisi. Aenean vulputate eleifend tellus. Aenean leo ligula, porttitor eu, consequat vitae.</p>
                            </div>

                            <div class="comment-actions">
                              <button class="action-btn like-btn" aria-label="Like comment">
                                <i class="bi bi-heart"></i>
                                <span>Like</span>
                              </button>
                              <button class="action-btn reply-btn" aria-label="Reply to comment">
                                <i class="bi bi-chat"></i>
                                <span>Reply</span>
                              </button>
                              <button class="action-btn share-btn" aria-label="Share comment">
                                <i class="bi bi-share"></i>
                                <span>Share</span>
                              </button>
                            </div>
                          </div>
                        </div>
                      </div>

                      <!-- Reply #2 -->
                      <div class="comment-box reply">
                        <div class="comment-wrapper">
                          <div class="avatar-wrapper">
                            <img src="assets/img/person/person-f-9.webp" alt="Avatar" loading="lazy">
                            <span class="status-indicator"></span>
                          </div>

                          <div class="comment-content">
                            <div class="comment-header">
                              <div class="user-info">
                                <h4>Alex Chen</h4>
                                <span class="time-badge">
                                  <i class="bi bi-clock"></i>
                                  30 minutes ago
                                </span>
                              </div>
                              <div class="engagement">
                                <span class="likes">
                                  <i class="bi bi-heart"></i>
                                  5
                                </span>
                              </div>
                            </div>

                            <div class="comment-body">
                              <p>Cras dapibus. Vivamus elementum semper nisi. Aenean vulputate eleifend tellus.</p>
                            </div>

                            <div class="comment-actions">
                              <button class="action-btn like-btn" aria-label="Like comment">
                                <i class="bi bi-heart"></i>
                                <span>Like</span>
                              </button>
                              <button class="action-btn reply-btn" aria-label="Reply to comment">
                                <i class="bi bi-chat"></i>
                                <span>Reply</span>
                              </button>
                              <button class="action-btn share-btn" aria-label="Share comment">
                                <i class="bi bi-share"></i>
                                <span>Share</span>
                              </button>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  <!-- Comment #2 -->
                  <div class="comment-thread">
                    <div class="comment-box">
                      <div class="comment-wrapper">
                        <div class="avatar-wrapper">
                          <img src="assets/img/person/person-f-7.webp" alt="Avatar" loading="lazy">
                          <span class="status-indicator"></span>
                        </div>

                        <div class="comment-content">
                          <div class="comment-header">
                            <div class="user-info">
                              <h4>Emily Watson</h4>
                              <span class="time-badge">
                                <i class="bi bi-clock"></i>
                                3 hours ago
                              </span>
                            </div>
                            <div class="engagement">
                              <span class="likes">
                                <i class="bi bi-heart"></i>
                                15
                              </span>
                            </div>
                          </div>

                          <div class="comment-body">
                            <p>Maecenas tempus, tellus eget condimentum rhoncus, sem quam semper libero, sit amet adipiscing sem neque sed ipsum.</p>
                          </div>

                          <div class="comment-actions">
                            <button class="action-btn like-btn" aria-label="Like comment">
                              <i class="bi bi-heart"></i>
                              <span>Like</span>
                            </button>
                            <button class="action-btn reply-btn" aria-label="Reply to comment">
                              <i class="bi bi-chat"></i>
                              <span>Reply</span>
                            </button>
                            <button class="action-btn share-btn" aria-label="Share comment">
                              <i class="bi bi-share"></i>
                              <span>Share</span>
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

            </div>

          </section><!-- /Blog Comments Section -->

          <!-- Blog Comment Form Section -->
          <section id="blog-comment-form" class="blog-comment-form section">

            <div class="container" data-aos="fade-up" data-aos-delay="100">

              <form method="post" role="form">

                <div class="form-header">
                  <h3>Leave a Comment</h3>
                  <p>Your email address will not be published. Required fields are marked *</p>
                </div>

                <div class="row gy-3">
                  <div class="col-md-6">
                    <div class="input-group">
                      <label for="name">Full Name *</label>
                      <input type="text" name="name" id="name" placeholder="Enter your full name" required="">
                      <span class="error-text">Please enter your name</span>
                    </div>
                  </div>

                  <div class="col-md-6">
                    <div class="input-group">
                      <label for="email">Email Address *</label>
                      <input type="email" name="email" id="email" placeholder="Enter your email address" required="">
                      <span class="error-text">Please enter a valid email address</span>
                    </div>
                  </div>

                  <div class="col-12">
                    <div class="input-group">
                      <label for="website">Website</label>
                      <input type="url" name="website" id="website" placeholder="Your website (optional)">
                    </div>
                  </div>

                  <div class="col-12">
                    <div class="input-group">
                      <label for="comment">Your Comment *</label>
                      <textarea name="comment" id="comment" rows="5" placeholder="Write your thoughts here..." required=""></textarea>
                      <span class="error-text">Please enter your comment</span>
                    </div>
                  </div>

                  <div class="col-12 text-center">
                    <button type="submit">Post Comment</button>
                  </div>
                </div>

              </form>

            </div>

          </section><!-- /Blog Comment Form Section -->

        </div>

        <div class="col-lg-4 sidebar">

          <div class="widgets-container" data-aos="fade-up" data-aos-delay="200">

            <!-- Search Widget -->
            <div class="search-widget widget-item">

              <h3 class="widget-title">Search</h3>
              <form action="">
                <input type="text">
                <button type="submit" title="Search"><i class="bi bi-search"></i></button>
              </form>

            </div><!--/Search Widget -->

            <!-- Recent Posts Widget -->
            <div class="recent-posts-widget widget-item">

              <h3 class="widget-title">Recent Posts</h3>

              <div class="post-item">
                <img src="assets/img/blog/blog-post-square-1.webp" alt="" class="flex-shrink-0">
                <div>
                  <h4><a href="blog-details.html">Nihil blanditiis at in nihil autem</a></h4>
                  <time datetime="2020-01-01">Jan 1, 2020</time>
                </div>
              </div><!-- End recent post item-->

              <div class="post-item">
                <img src="assets/img/blog/blog-post-square-2.webp" alt="" class="flex-shrink-0">
                <div>
                  <h4><a href="blog-details.html">Quidem autem et impedit</a></h4>
                  <time datetime="2020-01-01">Jan 1, 2020</time>
                </div>
              </div><!-- End recent post item-->

              <div class="post-item">
                <img src="assets/img/blog/blog-post-square-3.webp" alt="" class="flex-shrink-0">
                <div>
                  <h4><a href="blog-details.html">Id quia et et ut maxime similique occaecati ut</a></h4>
                  <time datetime="2020-01-01">Jan 1, 2020</time>
                </div>
              </div><!-- End recent post item-->

              <div class="post-item">
                <img src="assets/img/blog/blog-post-square-4.webp" alt="" class="flex-shrink-0">
                <div>
                  <h4><a href="blog-details.html">Laborum corporis quo dara net para</a></h4>
                  <time datetime="2020-01-01">Jan 1, 2020</time>
                </div>
              </div><!-- End recent post item-->

              <div class="post-item">
                <img src="assets/img/blog/blog-post-square-5.webp" alt="" class="flex-shrink-0">
                <div>
                  <h4><a href="blog-details.html">Et dolores corrupti quae illo quod dolor</a></h4>
                  <time datetime="2020-01-01">Jan 1, 2020</time>
                </div>
              </div><!-- End recent post item-->

            </div><!--/Recent Posts Widget -->

            <!-- Categories Widget -->
            <div class="categories-widget widget-item">

              <h3 class="widget-title">Categories</h3>
              <ul class="mt-3">
                <li><a href="#">General <span>(25)</span></a></li>
                <li><a href="#">Lifestyle <span>(12)</span></a></li>
                <li><a href="#">Travel <span>(5)</span></a></li>
                <li><a href="#">Design <span>(22)</span></a></li>
                <li><a href="#">Creative <span>(8)</span></a></li>
                <li><a href="#">Educaion <span>(14)</span></a></li>
              </ul>

            </div><!--/Categories Widget -->

            <!-- Tags Widget -->
            <div class="tags-widget widget-item">

              <h3 class="widget-title">Tags</h3>
              <ul>
                <li><a href="#">App</a></li>
                <li><a href="#">IT</a></li>
                <li><a href="#">Business</a></li>
                <li><a href="#">Mac</a></li>
                <li><a href="#">Design</a></li>
                <li><a href="#">Office</a></li>
                <li><a href="#">Creative</a></li>
                <li><a href="#">Studio</a></li>
                <li><a href="#">Smart</a></li>
                <li><a href="#">Tips</a></li>
                <li><a href="#">Marketing</a></li>
              </ul>

            </div><!--/Tags Widget -->

          </div>

        </div>

      </div>
    </div>

  @endsection