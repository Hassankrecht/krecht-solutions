<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Project;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;

class ProjectController extends Controller
{
    public function index()
    {
        $projects = Project::with('categories')->orderBy('order')->orderBy('id')->paginate(15);
        return view('admin.projects.index', compact('projects'));
    }

    public function create()
    {
        return view('admin.projects.create');
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'title_en'            => 'required|string|max:255',
            'title_ar'            => 'nullable|string|max:255',
            'description_en'      => 'nullable|string',
            'description_ar'      => 'nullable|string',
            'category_ids'        => 'required|array|min:1',
            'category_ids.*'      => 'exists:project_categories,id',
            'image'               => 'nullable|string|max:500',
            'image_upload'        => 'nullable|image|max:10240',
            'gallery_upload.*'    => 'nullable|image|max:10240',
            'video'               => 'nullable|string|max:500',
            'video_upload'        => 'nullable|mimes:mp4,avi,mov,webm,ogg|max:204800',
            'technologies_en'     => 'nullable|string|max:500',
            'technologies_ar'     => 'nullable|string|max:500',
            'is_active'           => 'boolean',
            'order'               => 'integer|min:0',
        ]);

        // Copy English values to original fields for backward compatibility
        $validated['title'] = $validated['title_en'];
        $validated['description'] = $validated['description_en'] ?? '';
        $validated['technologies'] = $this->parseTechnologies($request->input('technologies_en'));
        $validated['technologies_en'] = $this->parseTechnologies($request->input('technologies_en'));
        $validated['technologies_ar'] = $this->parseTechnologies($request->input('technologies_ar'));

        $validated['is_active'] = $request->boolean('is_active');
        $validated['order']     = $validated['order'] ?? 0;

        $validated['image']          = $this->handleImageUpload($request, null);
        $validated['gallery_images'] = $this->handleGalleryUpload($request, []);
        $validated['video']          = $this->handleVideoUpload($request, null);

        $categoryIds = $validated['category_ids'];
        unset($validated['category_ids']);

        $project = Project::create($validated);
        $project->categories()->sync($categoryIds);

        return redirect()->route('admin.projects.index')
            ->with('success', 'Project created successfully.');
    }

    public function edit(Project $project)
    {
        return view('admin.projects.edit', compact('project'));
    }

    public function update(Request $request, Project $project)
    {
        $validated = $request->validate([
            'title_en'            => 'required|string|max:255',
            'title_ar'            => 'nullable|string|max:255',
            'description_en'      => 'nullable|string',
            'description_ar'      => 'nullable|string',
            'category_ids'        => 'required|array|min:1',
            'category_ids.*'      => 'exists:project_categories,id',
            'image'               => 'nullable|string|max:500',
            'image_upload'        => 'nullable|image|max:10240',
            'gallery_upload.*'    => 'nullable|image|max:10240',
            'video'               => 'nullable|string|max:500',
            'video_upload'        => 'nullable|mimes:mp4,avi,mov,webm,ogg|max:204800',
            'technologies_en'     => 'nullable|string|max:500',
            'technologies_ar'     => 'nullable|string|max:500',
            'is_active'           => 'boolean',
            'order'               => 'integer|min:0',
        ]);

        // Copy English values to original fields for backward compatibility
        $validated['title'] = $validated['title_en'];
        $validated['description'] = $validated['description_en'] ?? '';
        $validated['technologies'] = $this->parseTechnologies($request->input('technologies_en'));
        $validated['technologies_en'] = $this->parseTechnologies($request->input('technologies_en'));
        $validated['technologies_ar'] = $this->parseTechnologies($request->input('technologies_ar'));

        $validated['is_active'] = $request->boolean('is_active');
        $validated['order']     = $validated['order'] ?? 0;

        $validated['image']          = $this->handleImageUpload($request, $project->image);
        $validated['gallery_images'] = $this->handleGalleryUpload($request, $project->gallery_images ?? []);
        $validated['video']          = $this->handleVideoUpload($request, $project->video);

        $categoryIds = $validated['category_ids'];
        unset($validated['category_ids']);

        $project->update($validated);
        $project->categories()->sync($categoryIds);

        return redirect()->route('admin.projects.index')
            ->with('success', 'Project updated successfully.');
    }

    private function parseTechnologies(?string $input): array
    {
        if (empty($input)) {
            return [];
        }
        return array_values(array_filter(array_map('trim', explode(',', $input))));
    }

    public function destroy(Project $project)
    {
        $project->delete();

        return redirect()->route('admin.projects.index')
            ->with('success', 'Project deleted successfully.');
    }

    private function handleImageUpload(Request $request, ?string $current): ?string
    {
        if ($request->boolean('remove_image')) {
            return null;
        }

        if ($request->hasFile('image_upload') && $request->file('image_upload')->isValid()) {
            $file     = $request->file('image_upload');
            $filename = time() . '_' . Str::slug(pathinfo($file->getClientOriginalName(), PATHINFO_FILENAME))
                        . '.' . $file->getClientOriginalExtension();
            $path = $file->storeAs('projects', $filename, 'public');
            return 'storage/' . $path;
        }

        $path = trim($request->input('image', ''));
        return $path !== '' ? $path : $current;
    }

    private function handleGalleryUpload(Request $request, array $existing): array
    {
        $toRemove = $request->input('remove_gallery', []);
        $gallery  = array_values(array_filter($existing, fn ($img) => !in_array($img, $toRemove)));

        if ($request->hasFile('gallery_upload')) {
            foreach ($request->file('gallery_upload') as $file) {
                if ($file->isValid()) {
                    $filename = time() . '_' . uniqid() . '_'
                                . Str::slug(pathinfo($file->getClientOriginalName(), PATHINFO_FILENAME))
                                . '.' . $file->getClientOriginalExtension();
                    $path = $file->storeAs('projects', $filename, 'public');
                    $gallery[] = 'storage/' . $path;
                }
            }
        }

        return $gallery;
    }

    private function handleVideoUpload(Request $request, ?string $current): ?string
    {
        if ($request->boolean('remove_video')) {
            return null;
        }

        if ($request->hasFile('video_upload') && $request->file('video_upload')->isValid()) {
            $file     = $request->file('video_upload');
            $filename = time() . '_' . Str::slug(pathinfo($file->getClientOriginalName(), PATHINFO_FILENAME))
                        . '.' . $file->getClientOriginalExtension();
            $path = $file->storeAs('projects', $filename, 'public');
            return 'storage/' . $path;
        }

        $path = trim($request->input('video', ''));
        return $path !== '' ? $path : $current;
    }
}
